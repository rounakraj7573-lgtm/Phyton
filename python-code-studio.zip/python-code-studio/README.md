# Python Code Studio

A responsive Python playground and beginner learning page. Python executes in the browser using Pyodide (WebAssembly); no Python server is needed for this starter project.

## Features
- Run Python 3 code in the browser
- Output and error display
- Tab indentation, line numbers, cursor position
- Copy/clear code, clear output, Ctrl/Cmd + Enter shortcut
- Example programs and beginner lessons
- Responsive layout and light/dark theme toggle

## Deploy on Vercel from GitHub
1. Upload all files in this folder to the root of your GitHub repository.
2. Open https://vercel.com/new and sign in with GitHub.
3. Import your repository.
4. Framework Preset: **Other**.
5. Build Command: leave empty; Output Directory: `.` (or leave default if Vercel detects the static site).
6. Click **Deploy**.

## Important
- Internet access is required to download Pyodide the first time.
- This browser-based runtime is intended for learning and trusted code. It is not a hardened multi-user server sandbox.
- Some operating-system functions and native Python packages are not available in Pyodide.
- Never paste private credentials or secrets into code that you do not trust.
