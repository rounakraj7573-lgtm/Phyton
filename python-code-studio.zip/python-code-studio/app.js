const codeInput = document.getElementById('codeInput');
const lineNumbers = document.getElementById('lineNumbers');
const output = document.getElementById('output');
const runBtn = document.getElementById('runBtn');
const runStatus = document.getElementById('runStatus');
const cursorInfo = document.getElementById('cursorInfo');
let pyodide = null;
let loadingPromise = null;

const examples = {
  hello: 'print("Hello, World!")\\nname = "Python learner"\\nprint(f"Welcome, {name}!")',
  loops: 'for number in range(1, 6):\\n    print("Number:", number)',
  function: 'def greet(name):\\n    return f"Namaste, {name}!"\\n\\nprint(greet("Dost"))',
  list: 'fruits = ["apple", "mango", "banana"]\\nfor fruit in fruits:\\n    print(fruit)'
};

function updateLines() {
  const count = codeInput.value.split('\\n').length;
  lineNumbers.textContent = Array.from({length: count}, (_, i) => i + 1).join('\\n');
}
function updateCursor() {
  const before = codeInput.value.slice(0, codeInput.selectionStart);
  const lines = before.split('\\n');
  cursorInfo.textContent = `Ln ${lines.length}, Col ${lines[lines.length - 1].length + 1}`;
}
codeInput.addEventListener('input', updateLines);
codeInput.addEventListener('keyup', updateCursor);
codeInput.addEventListener('click', updateCursor);
codeInput.addEventListener('scroll', () => { lineNumbers.scrollTop = codeInput.scrollTop; });
codeInput.addEventListener('keydown', e => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const start = codeInput.selectionStart, end = codeInput.selectionEnd;
    codeInput.setRangeText('    ', start, end, 'end');
    updateLines();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runCode(); }
});
updateLines();

async function getPyodide() {
  if (pyodide) return pyodide;
  if (loadingPromise) return loadingPromise;
  if (typeof loadPyodide !== 'function') throw new Error('Python runtime load नहीं हुआ। Internet connection जाँचें और page refresh करें।');
  loadingPromise = loadPyodide({ indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.27.7/full/' });
  pyodide = await loadingPromise;
  return pyodide;
}

async function runCode() {
  runBtn.disabled = true;
  runBtn.innerHTML = '<span>◌</span> Starting…';
  runStatus.textContent = 'Loading Python';
  output.textContent = 'Python runtime शुरू हो रहा है… पहली बार थोड़ा समय लग सकता है।';
  try {
    const runtime = await getPyodide();
    let captured = [];
    runtime.setStdout({ batched: text => captured.push(text) });
    runtime.setStderr({ batched: text => captured.push(text) });
    try {
      await runtime.runPythonAsync(codeInput.value);
      output.textContent = captured.join('\\n') || 'Code सफलतापूर्वक चला। (कोई output नहीं)';
      runStatus.textContent = 'Finished';
    } catch (err) {
      output.textContent = captured.length ? captured.join('\\n') + '\\n' + String(err) : String(err);
      runStatus.textContent = 'Error';
    }
  } catch (err) {
    output.textContent = String(err);
    runStatus.textContent = 'Could not start';
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = '<span>▶</span> Run code';
  }
}
runBtn.addEventListener('click', runCode);
document.getElementById('clearBtn').addEventListener('click', () => { codeInput.value = ''; updateLines(); updateCursor(); codeInput.focus(); });
document.getElementById('clearOutputBtn').addEventListener('click', () => { output.textContent = 'Output cleared.'; runStatus.textContent = 'Ready'; });
document.getElementById('copyBtn').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(codeInput.value); document.getElementById('copyBtn').textContent = 'Copied!'; }
  catch { output.textContent = 'Copy नहीं हो पाया। Code को manually select करके copy करें.'; }
  setTimeout(() => document.getElementById('copyBtn').textContent = 'Copy', 1400);
});
document.getElementById('themeBtn').addEventListener('click', () => {
  document.body.classList.toggle('light');
  document.getElementById('themeBtn').textContent = document.body.classList.contains('light') ? '☾' : '☼';
});
function loadExample(name) {
  codeInput.value = examples[name] || examples.hello;
  updateLines(); updateCursor();
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.tab === 'editor'));
  document.getElementById('editorView').classList.remove('hidden');
  document.getElementById('learnView').classList.add('hidden');
  codeInput.focus();
}
document.querySelectorAll('[data-example]').forEach(button => button.addEventListener('click', () => loadExample(button.dataset.example)));
document.querySelectorAll('[data-tab]').forEach(button => button.addEventListener('click', () => {
  const learning = button.dataset.tab === 'learn';
  document.getElementById('editorView').classList.toggle('hidden', learning);
  document.getElementById('learnView').classList.toggle('hidden', !learning);
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b === button));
}));
